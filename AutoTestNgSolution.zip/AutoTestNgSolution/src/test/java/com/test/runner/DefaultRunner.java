package com.test.runner;

import org.testng.annotations.DataProvider;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

/**
 * <h1>DefaultRunner</h1>  The DefaultRunner class will get called first. This config is made in pom file. 
 * We specify tags to be run here & we can still override the tag from cli 
 */

@CucumberOptions(tags = "@LoginwithCredentials", glue = { "com.test.stepdefs" }, 
				plugin = {"json:target/cucumber.json",
						"pretty", "html:target/cucumber-reports/report.html",
					    "json:target/cucumber-reports/CucumberTestReport.json"},
				features = { "src/test/resources/features/" })
public class DefaultRunner extends AbstractTestNGCucumberTests {
	@Override
	@DataProvider(parallel = true)
	public Object[][] scenarios() {
		return super.scenarios();
	}


}
