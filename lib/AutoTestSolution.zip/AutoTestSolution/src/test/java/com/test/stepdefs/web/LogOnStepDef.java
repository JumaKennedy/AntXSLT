package com.test.stepdefs.web;
import com.test.framework.ScenarioContext;
import com.test.pageclass.web.LogOnPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LogOnStepDef {
   
	private ScenarioContext sc;
    private LogOnPage logOnPage;

    public LogOnStepDef(ScenarioContext scenarioContext) {
        this.sc = scenarioContext;
        logOnPage = new LogOnPage(sc);
    }

    @Given("I am on Login page")
    public void i_am_on_login_page() {
       
    	logOnPage.visit();
    }

    @When("I enters valid credentials: username and a apassword")
    public void i_enters_valid_credentials_username_and_a_apassword() {
       
    	logOnPage.loginToSite();
    }

    @Then("I should be able to login sucessfully")
    public void i_should_be_able_to_login_sucessfully() {
    	logOnPage.getProfileTitle();
        
    }

    @Then("I logout")
    public void i_logout() {
    	logOnPage.logoutOfSite();
        
    }
    
    
}